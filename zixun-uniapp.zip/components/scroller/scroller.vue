<template>
	<view class="scroller-warp">
		<scroll-view
			:id="viewId"
			class="scroller"
			:class="{ 'scroller-fixed': fixed }"
			:style="{ 'padding-top': padTop, 'padding-bottom': padBottom, top: fixedTop, bottom: fixedBottom }"
			:scroll-top="scrollTop"
			:scroll-with-animation="scrollAnim"
			@scroll="scroll"
			@touchstart="touchstartEvent"
			@touchmove="touchmoveEvent"
			@touchend="touchendEvent"
			@touchcancel="touchendEvent"
			:scroll-y="scrollAble"
			:throttle="scroller.optUp.onScroll == null"
			:enable-back-to-top="true"
		>
			<view :style="{ transform: translateY, transition: transition }">
				<!-- 下拉加载区域-->
				<view v-if="scroller.optDown.use" class="scroller-downwarp">
					<view class="downwarp-content">
						<view class="loading">
							<image
								class="load-icon"
								src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAQj0lEQVR4Xu1de5AcxXn/fXMPSq5AiPEDYuIyOJgqE2OSgjg6qEASUQYSA8ZAeAk/ZG53BVKk3VnJup3VabWzp8fO3l6dhHbmKIgDCRCBsAMGbAOxXAaRlGOHR0EFIgNVIWXhAFFEYhX3mC/Ve3cqndjb7t2d2dnHTJX+Uf/66+/79W/7enq6+yN04TNi2Z91wcvB+DQR9TDjDdLwWCoRfarb6KBuCzibL20iouFKcTNzJp2MbeomTrpKAOZo6RNw6c0qHXxIA5YO6dGXu0UE3SUAy9kG8LpqncvAjrQeXR0KoAMZyFn2dxi4snpovN/QY2d0YPgVQ+qyEcD+EYCLZJ1r6NGu4aVrAhWdblqhAI4VfyiACsNBOALIxkgPy3OWvQrAjcx8OoheAdGe41z33mQy9isPmymbCnIEyOdLH3tf024A81cAnAZgCoQdb/VN3r5j9er3vY5V1V6gI4CZL+0G0TUVnP1XbXL64qGh295RDUQFF5QARkZ2nuT29z4B4Pcr+Ll3aspdkdmw8jWVGLzGBCYA0yptAehbiwbEtMdIRq72MuCgBGDmnQdB5V9+5Ydoj5HwNlZV3gIRQG678wes8T4Ax0leyW429Ng9qsHIcEEIwLRKywG6W+YbNJxnxKP/IsV5DAhEANl86SIiEq9kkv7Hc+/0/HqgGI8flkFVypstgLWjo0tOmvnQPhDOkfnnuvz1jeti35bhvC5vbQEAYGYjnYzlvAi82QLI5kspIjJVfA/qO0QgAhge3t3fd/y7BwEsUSDnHY20gaHE4KsK2KqQZgpgpDDxGZdd8WfuJBW/e7TeMzbEv7lfBeslJhABiABylvMPDL5cJRgiclKJSFQFWw3TTAHkCo7NzBEVnwn0cEqPXKGC9RoTmABGRicudF13r2pAzNrF6eTgk6r4SrhmCSCbn1hG5IrXPqVH07SLhuKDP1YCewwKTAAiDrPg7ADzbWox8eOGHrtMDVsZ1SwBmFbpMYAuVfKVaKeRiIjFsECeQAWQzd9xGtGM+Dt5skr0RLwilYjdpYINagTIFUrfYKY7FX08wNwzkE7e8roi3nNYoAIojwJWaR1A2xQje2nqvcmBTGb1IUX8ApjfI8Dw8PgJfcf3C0GfpeYfrzf02HY1rD+owAUwPDzc23v8yfsIdJ5KiI28LvktgGrbzY6NjcE/nX7vwEAmk5lWidsvTOACEIFtzpeu04juUwqScMglbWBjfPAlJfxRID8FsHl04ixNvPYxTlDxy2W+fmMydr8K1k9MSwig/KdAtl6+gAW6y9AjK2olxk8BmJZzJ8DfUPLJh+8cSu1WALWOAAoTA2D3GdVACNplKX3wcVX87HzDnw0hOWviUob7mLIvpJ1vJAbFXCHwp2UEIJjIWc4og9eqscJPGnrsYjXsLMovAZhW6QmAlqn4QqBiSo/EVbDNwLSUALaN33Hq5PszzxLhVJXgmTmaTsYcFaxfAsjmSxEislV8YMab/cf1LF2/+pZqW9NVTHmGaSkBiKiyVmktgUYVI3xVm5weUN044vUIMLfRQwzln1Hxl8HxtB4rqmCbhWk5Acz+UkvPADSgQgIR5VKJiKGC9VoAuYJjMnNKpW2A9xl67Hw1bPNQrSmAQukrYHpQhQYCDqNHG0itHXxOhs9Z9h4GrqqOUzsXkCtOnIMZdx+rfdEEiK82ErE9Mh+bXV6TAMROHpfc8nvu9P+etC+TuXbSL4dzlnMfg69Ts0/3GHrkZhnWzNsFEGQTsAlDj0q/4pmWczfEAVOFh0D3p/TI9QrQuiFik8185XQypvyRTVkAc3v4xAx9fhvXYQY/QdDyhh55um7PF6m4xZo4bwbl7+m9KrY10r40lBj8XjXsiGVf5QJVf4XM/CcyAnPWrksZmupr33QPtIEN+uBPVeKoBZPd7nyaNI6D+RoQffRIXcKYkYgqvU0pCaDK7t3ZNhmj1EtWam3kl7UEIMOaCmf5jrLxiKFHpfsLsnn7USJU/KqousxsFuwiGGtk/s+W03ZDj6xXw6qhHMfpe/sQx11CnICPVazF/ICRjF0rsygVgGk53wJ4i9QQ4TUXZKUTkZIMq1o+vP32k/u0HjEKiH30suewoUc/JAOJ8mzBvkwDhphxJoAeAK+5Lu9U3ZOnOpkE8PqUOzOQWXfrARW/VDCmZV8PRhyEc2V4lYOuCgKwXwDwOVljR5U/QUA+pUeVN0RUs23mS7eBaIe8fXrB0COfl+MaRygLgHmVkYztbLxFYKRYOp9nKC6fxB7dmnxCKxdAvvSrBX9fFKMh5tLkNFteHHjI5kt7iejCak0T6K5UHd8HFMNZADMt+68BfK1aXWb+cToZkx5ElbU/vNX5ZG8vi6H+r2TYSuWyY25yAVj2TwBcUE/jAH4JgmUkoqoLOxWbyRZ2XU7Q7gNj0SGeCMuadcWLaTkXACx4WfRhcq9IJ1Y+XCdv5WpmwY6Xh3vgE/XaaVwABWcNmBtdvXpaIy0/lBism5CRvL3UJewCKuyxZ1plJCOeDLWqRJt55zYQf/BPE/N/QdNuNRKRB1RtHYsbseyrGRDD/dJ6bYh6DC6m9VjV117pCFA+1Ej0/UXOtdXq37c1IF/vFSzDxeKJfe6SYfCcCAjPEbs/TOkra/oqWKvTi+Gz2+1LSOMLAfqjOczL7NJoel3kF/W0YY6W/hAuiQ77y3rqL6hD9FJfn3aJ7LuDVADCaHnNu6/PqXq+TdljOkjkWgf6pqwgT8Uqu9sEYK7onMLTLGb2ovO1hpsk/FxjLFf5oSkJYN6huXNuwknpUSdZEAz+GRHljUT072XYTi7PWvYqQrnjP9VwnIS3wDz2Vv9UUfXHVZMAhIOjo6NLDvOSOHN5qPpwo06rvKs22kYr1jfz9hVzv/g/9sI/AnZMau5YJl7bMfOaBTDvbHbbrjOpRxMiGPQgAKX1dw/aCdxELr/rbGhakhk3eeEMAQ/NuO7YxnUrq76VLNZW3QKYN5iz7It5dmXqkkYCcuGeu1Ff+bNGbLR6XbECSYyJRl7r5mMk4J9nmMca3VjasACOjAh5ewXNTmI+W09HEGF5KhH923rqtkOdrVud35zq4xeI8clG/CXQmy7csen3DhQzmYzbiC1R1zMBCGMiyOleFiIQ/36jNudog6FHttZWp33Q2YITI2axjlHXQ0TssjtG5BaNxK3/UZeRCpU8FcC8/c2jzuc0tyyEqsulR/vjEs7ZmIg+71VgrWbHtGyxd7Gu+RKDdxNx0Uis/Cev4/JFAEfmB3nnz5nKQvjTao6LiUxKjy5+h47XUQdgz7RssZj2xVqaZsYzxFw01vm3k8hXARyZH5SHP/FngX+3AgHPT4OWbdIjb9dCTrths/nSLUQkJoAqzxti+d1IxsZVwI1gmiIA4eDI+F0fdSenVgB8A4BTiPAKgx70607ARkjxo+4my/lIL9xnAar0I5hrkiYBd2zKdYte7iGQjL5+hBvarMRArmD/GTMWu+Ti71y4xWa/CjdtBAglMcvA7ATZvQGgL4JwJhhPaaRNyPYz+sVfKAC/mG0Tu6EA2qSj/HIzFIBfzLaJ3VAAbdJRfrkZCsAvZtvEbiiANukov9wMBeAXs21iNxRAm3SUX24eEUB5lcrFZUT4FDe01YvEodHXNOKfN3Kpo18Bt6Jd77ivHh0B7x6bJrcsgFrut6uFQCa+N52I3VhLnW7D+sW9jMf5g7A0m0gZzwJq99vJDB9b3uk7fWrl42i839xLfCunyaUaj2DXHK/Yu5bSo/MHJ2qu38kVspY9TkBgF0WLHdmklk61sW6YmuLTMhtibzRmpfNqm1bp36t/HvY7Zt4vBKBwb05jjoQCqMxfSwhA8d6cRhTwoqFHz27EQKfWbWSfoEecTNBIYeIvXHYf8cjgB8yoXrviV/utbNdv7mWxi3uVfH0NhOI9NTJHO7k88NfAeXLNUftcuLh1Lr16IwcVDxKwF0wPpJKRezu587yKzUPuZS6JifheaLh9PklluBQso6zDy0MBdHgHy8ILBSBjqMPLQwF0eAfLwgsFIGOow8tDAXR4B8vCCwUgY6jDy0MBdHgHy8ILBSBjqMPLQwF0eAfLwgsFIGOow8tDAXR4B8vCCwUgY6jDy0MBdHgHy8LzXAC5gn0zM74O4GwQ9oP5H11Nu3djPPKizJmwvPkMeCaAEcu50p3N+1vx7luVbFzNDz9ssWEBbM47XyDCGpLn+Ht1qufwFzJr1x4MaW8dBuoWgFm4/XeYNZHnV6RPU7LDcL+c1ld+t3XCDz1R6rijaRoeHu7tO+GUNXN582rKZRNuEG09wdUkANMq3QimNSo56yqFGgqgjQUgzR6qEBszvplORu9UgIaQJjGgNAJ40fkAfmDo0YZyCjSJk65qRioA07LFDdfipuv6H6KXNOZrVZIY1d9IWLMeBhQE4PwE4HoTR4oXhHs08Naw8+vpHv/rSAWQs5z/ZPBv1+4KPUmMsVQy8mjtdcMazWJAKgDTsl+vMaXZy8w8lk7G7mhWEGE79TMgF8Bs/tqCQhP/DWBsqn9yLLN69SEFfAhpAQakAlg1Pn7cxyf7RbaLRTNhE7MzRdrYJj3yby0QU+hCDQxIBSBsDW/ZdXpff892MC9I60Kgh0EYSyUiP6qhzRDaQgwoCWDeX3GK1Z3m3xNXyfUQ7Q5n9i3Uk3W6UpMA6mwjrNbCDIQCaOHOaYZroQCawXILtxEKoIU7pxmuhQJoBsst3EZLCWBz3l6qiX2FRNcIzsQtowA93TvTm1m/fsV7Lcxj27rWMgIwC841YN5diUkhBAJ9bShcaPJcaC0hgJG8vdQl7JNEN2Ho0YjnDHS5wZYQQM6yH2DgallfGHq0JfyV+dlO5YETujlfuk4juk+FtFAAKizVhglUAGKHce/xJ+8j0HkqbocCUGGpNkygAjCt0jqAtim53AHXzopDNBq5V4FxGgi/ALRHDT3ytFL8PoECE8CW0V2nz7iamPh9XCU2Il7RzjmIFksOweD703rsehUO/MAEJoCcZe9klO8mlj4Mfjitx66QAlsUILsWnhlb0snoUBDuByYA07LfgWJ2MtflCzauiz0TBEGNtjlcLJ7YN7NE7Jaq+gSVVCMQAWTzpYuISHETCW039Mh6GYH1lG8bv+PUX//fdK+f6WxUYw3q1FRrC4DxyjTRBZv0yNv1dPBidXIF+yYwVjKwdA7zIjM/lE7GNnnZjrClKgAifDWViN7tdfsyey0tAD8mfqbl3A3w8orE+PCmMTw+fkLfZP//SDuCsCyViD4lw3ldHogAZn8Z9j1EuGmxgAh4KKVHF+xBbDT4udtL/qaaHWK60etEFwqJuR4x9OjljcZXT/3ABFBOmki0G8xnVXD8+WnQMs+Hfsv+DgNXVhUA8N2UHv1yPWQuVmeT5XykF/wkgM9/ABPwsbnABCCImMucmTw6TQ2Di/39vaPrV9/yppedIGyZli1m4ydK7B409Ohved22mHBOTk7HCSSu0RHPuwAe14CRIDfXBioAr0mW2TMtm2UYUd5NS86hACooIhSAys+kDTHhCPDBTuuyEUAlVy/vN/TYGW2o77pc7jIB2OKiC3HhRbWnq3YedZUAVFK1inSqQ4nB79X1c2rDSl0lANE/1VK1BrUeH6Ruuk4A5fWAhWlyxX8tSKcaZIc0u+3/B0Y1GSaZrFQgAAAAAElFTkSuQmCC"
							></image>
							<text class="load-text">{{ downText }}</text>
						</view>
					</view>
				</view>
				<!-- 列表内容 -->
				<slot></slot>

				<!-- 空布局 -->
				<view v-if="isShowEmpty" class="scroller-empty" :class="{ 'empty-fixed': optEmpty.fixed }" :style="{ 'z-index': optEmpty.zIndex, top: optEmpty.top }">
					<block v-if="optEmpty.type == 'normal'">
						<image v-if="optEmpty.icon" class="empty-icon" src="/static/images/icon-no-data-01.png" mode="widthFix" />
						<view v-if="optEmpty.tip" class="empty-tip" style="color: #848c98;">{{ optEmpty.tip }}</view>
						<view v-if="optEmpty.btnText" class="empty-btn" @click="emptyClick">{{ optEmpty.btnText }}</view>
					</block>
					<block v-else>
						<image v-if="optEmpty.icon" class="empty-icon" :src="optEmpty.icon" mode="widthFix" />
						<view v-if="optEmpty.tip" class="empty-tip">{{ optEmpty.tip }}</view>
						<view v-if="optEmpty.btnText" class="empty-btn" @click="emptyClick">{{ optEmpty.btnText }}</view>
					</block>
				</view>

				<!-- 上拉加载区域 -->
				<view v-if="scroller.optUp.use" class="scroller-upwarp">
					<!-- 加载中 (此处不能用v-if,否则android小程序快速上拉可能会不断触发上拉回调) -->
					<view class="loading" v-show="isUpLoading">
						<image
							class="load-icon"
							src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAQj0lEQVR4Xu1de5AcxXn/fXMPSq5AiPEDYuIyOJgqE2OSgjg6qEASUQYSA8ZAeAk/ZG53BVKk3VnJup3VabWzp8fO3l6dhHbmKIgDCRCBsAMGbAOxXAaRlGOHR0EFIgNVIWXhAFFEYhX3mC/Ve3cqndjb7t2d2dnHTJX+Uf/66+/79W/7enq6+yN04TNi2Z91wcvB+DQR9TDjDdLwWCoRfarb6KBuCzibL20iouFKcTNzJp2MbeomTrpKAOZo6RNw6c0qHXxIA5YO6dGXu0UE3SUAy9kG8LpqncvAjrQeXR0KoAMZyFn2dxi4snpovN/QY2d0YPgVQ+qyEcD+EYCLZJ1r6NGu4aVrAhWdblqhAI4VfyiACsNBOALIxkgPy3OWvQrAjcx8OoheAdGe41z33mQy9isPmymbCnIEyOdLH3tf024A81cAnAZgCoQdb/VN3r5j9er3vY5V1V6gI4CZL+0G0TUVnP1XbXL64qGh295RDUQFF5QARkZ2nuT29z4B4Pcr+Ll3aspdkdmw8jWVGLzGBCYA0yptAehbiwbEtMdIRq72MuCgBGDmnQdB5V9+5Ydoj5HwNlZV3gIRQG678wes8T4Ax0leyW429Ng9qsHIcEEIwLRKywG6W+YbNJxnxKP/IsV5DAhEANl86SIiEq9kkv7Hc+/0/HqgGI8flkFVypstgLWjo0tOmvnQPhDOkfnnuvz1jeti35bhvC5vbQEAYGYjnYzlvAi82QLI5kspIjJVfA/qO0QgAhge3t3fd/y7BwEsUSDnHY20gaHE4KsK2KqQZgpgpDDxGZdd8WfuJBW/e7TeMzbEv7lfBeslJhABiABylvMPDL5cJRgiclKJSFQFWw3TTAHkCo7NzBEVnwn0cEqPXKGC9RoTmABGRicudF13r2pAzNrF6eTgk6r4SrhmCSCbn1hG5IrXPqVH07SLhuKDP1YCewwKTAAiDrPg7ADzbWox8eOGHrtMDVsZ1SwBmFbpMYAuVfKVaKeRiIjFsECeQAWQzd9xGtGM+Dt5skr0RLwilYjdpYINagTIFUrfYKY7FX08wNwzkE7e8roi3nNYoAIojwJWaR1A2xQje2nqvcmBTGb1IUX8ApjfI8Dw8PgJfcf3C0GfpeYfrzf02HY1rD+owAUwPDzc23v8yfsIdJ5KiI28LvktgGrbzY6NjcE/nX7vwEAmk5lWidsvTOACEIFtzpeu04juUwqScMglbWBjfPAlJfxRID8FsHl04ixNvPYxTlDxy2W+fmMydr8K1k9MSwig/KdAtl6+gAW6y9AjK2olxk8BmJZzJ8DfUPLJh+8cSu1WALWOAAoTA2D3GdVACNplKX3wcVX87HzDnw0hOWviUob7mLIvpJ1vJAbFXCHwp2UEIJjIWc4og9eqscJPGnrsYjXsLMovAZhW6QmAlqn4QqBiSo/EVbDNwLSUALaN33Hq5PszzxLhVJXgmTmaTsYcFaxfAsjmSxEislV8YMab/cf1LF2/+pZqW9NVTHmGaSkBiKiyVmktgUYVI3xVm5weUN044vUIMLfRQwzln1Hxl8HxtB4rqmCbhWk5Acz+UkvPADSgQgIR5VKJiKGC9VoAuYJjMnNKpW2A9xl67Hw1bPNQrSmAQukrYHpQhQYCDqNHG0itHXxOhs9Z9h4GrqqOUzsXkCtOnIMZdx+rfdEEiK82ErE9Mh+bXV6TAMROHpfc8nvu9P+etC+TuXbSL4dzlnMfg69Ts0/3GHrkZhnWzNsFEGQTsAlDj0q/4pmWczfEAVOFh0D3p/TI9QrQuiFik8185XQypvyRTVkAc3v4xAx9fhvXYQY/QdDyhh55um7PF6m4xZo4bwbl7+m9KrY10r40lBj8XjXsiGVf5QJVf4XM/CcyAnPWrksZmupr33QPtIEN+uBPVeKoBZPd7nyaNI6D+RoQffRIXcKYkYgqvU0pCaDK7t3ZNhmj1EtWam3kl7UEIMOaCmf5jrLxiKFHpfsLsnn7USJU/KqousxsFuwiGGtk/s+W03ZDj6xXw6qhHMfpe/sQx11CnICPVazF/ICRjF0rsygVgGk53wJ4i9QQ4TUXZKUTkZIMq1o+vP32k/u0HjEKiH30suewoUc/JAOJ8mzBvkwDhphxJoAeAK+5Lu9U3ZOnOpkE8PqUOzOQWXfrARW/VDCmZV8PRhyEc2V4lYOuCgKwXwDwOVljR5U/QUA+pUeVN0RUs23mS7eBaIe8fXrB0COfl+MaRygLgHmVkYztbLxFYKRYOp9nKC6fxB7dmnxCKxdAvvSrBX9fFKMh5tLkNFteHHjI5kt7iejCak0T6K5UHd8HFMNZADMt+68BfK1aXWb+cToZkx5ElbU/vNX5ZG8vi6H+r2TYSuWyY25yAVj2TwBcUE/jAH4JgmUkoqoLOxWbyRZ2XU7Q7gNj0SGeCMuadcWLaTkXACx4WfRhcq9IJ1Y+XCdv5WpmwY6Xh3vgE/XaaVwABWcNmBtdvXpaIy0/lBism5CRvL3UJewCKuyxZ1plJCOeDLWqRJt55zYQf/BPE/N/QdNuNRKRB1RtHYsbseyrGRDD/dJ6bYh6DC6m9VjV117pCFA+1Ej0/UXOtdXq37c1IF/vFSzDxeKJfe6SYfCcCAjPEbs/TOkra/oqWKvTi+Gz2+1LSOMLAfqjOczL7NJoel3kF/W0YY6W/hAuiQ77y3rqL6hD9FJfn3aJ7LuDVADCaHnNu6/PqXq+TdljOkjkWgf6pqwgT8Uqu9sEYK7onMLTLGb2ovO1hpsk/FxjLFf5oSkJYN6huXNuwknpUSdZEAz+GRHljUT072XYTi7PWvYqQrnjP9VwnIS3wDz2Vv9UUfXHVZMAhIOjo6NLDvOSOHN5qPpwo06rvKs22kYr1jfz9hVzv/g/9sI/AnZMau5YJl7bMfOaBTDvbHbbrjOpRxMiGPQgAKX1dw/aCdxELr/rbGhakhk3eeEMAQ/NuO7YxnUrq76VLNZW3QKYN5iz7It5dmXqkkYCcuGeu1Ff+bNGbLR6XbECSYyJRl7r5mMk4J9nmMca3VjasACOjAh5ewXNTmI+W09HEGF5KhH923rqtkOdrVud35zq4xeI8clG/CXQmy7csen3DhQzmYzbiC1R1zMBCGMiyOleFiIQ/36jNudog6FHttZWp33Q2YITI2axjlHXQ0TssjtG5BaNxK3/UZeRCpU8FcC8/c2jzuc0tyyEqsulR/vjEs7ZmIg+71VgrWbHtGyxd7Gu+RKDdxNx0Uis/Cev4/JFAEfmB3nnz5nKQvjTao6LiUxKjy5+h47XUQdgz7RssZj2xVqaZsYzxFw01vm3k8hXARyZH5SHP/FngX+3AgHPT4OWbdIjb9dCTrths/nSLUQkJoAqzxti+d1IxsZVwI1gmiIA4eDI+F0fdSenVgB8A4BTiPAKgx70607ARkjxo+4my/lIL9xnAar0I5hrkiYBd2zKdYte7iGQjL5+hBvarMRArmD/GTMWu+Ti71y4xWa/CjdtBAglMcvA7ATZvQGgL4JwJhhPaaRNyPYz+sVfKAC/mG0Tu6EA2qSj/HIzFIBfzLaJ3VAAbdJRfrkZCsAvZtvEbiiANukov9wMBeAXs21iNxRAm3SUX24eEUB5lcrFZUT4FDe01YvEodHXNOKfN3Kpo18Bt6Jd77ivHh0B7x6bJrcsgFrut6uFQCa+N52I3VhLnW7D+sW9jMf5g7A0m0gZzwJq99vJDB9b3uk7fWrl42i839xLfCunyaUaj2DXHK/Yu5bSo/MHJ2qu38kVspY9TkBgF0WLHdmklk61sW6YmuLTMhtibzRmpfNqm1bp36t/HvY7Zt4vBKBwb05jjoQCqMxfSwhA8d6cRhTwoqFHz27EQKfWbWSfoEecTNBIYeIvXHYf8cjgB8yoXrviV/utbNdv7mWxi3uVfH0NhOI9NTJHO7k88NfAeXLNUftcuLh1Lr16IwcVDxKwF0wPpJKRezu587yKzUPuZS6JifheaLh9PklluBQso6zDy0MBdHgHy8ILBSBjqMPLQwF0eAfLwgsFIGOow8tDAXR4B8vCCwUgY6jDy0MBdHgHy8ILBSBjqMPLQwF0eAfLwgsFIGOow8tDAXR4B8vCCwUgY6jDy0MBdHgHy8LzXAC5gn0zM74O4GwQ9oP5H11Nu3djPPKizJmwvPkMeCaAEcu50p3N+1vx7luVbFzNDz9ssWEBbM47XyDCGpLn+Ht1qufwFzJr1x4MaW8dBuoWgFm4/XeYNZHnV6RPU7LDcL+c1ld+t3XCDz1R6rijaRoeHu7tO+GUNXN582rKZRNuEG09wdUkANMq3QimNSo56yqFGgqgjQUgzR6qEBszvplORu9UgIaQJjGgNAJ40fkAfmDo0YZyCjSJk65qRioA07LFDdfipuv6H6KXNOZrVZIY1d9IWLMeBhQE4PwE4HoTR4oXhHs08Naw8+vpHv/rSAWQs5z/ZPBv1+4KPUmMsVQy8mjtdcMazWJAKgDTsl+vMaXZy8w8lk7G7mhWEGE79TMgF8Bs/tqCQhP/DWBsqn9yLLN69SEFfAhpAQakAlg1Pn7cxyf7RbaLRTNhE7MzRdrYJj3yby0QU+hCDQxIBSBsDW/ZdXpff892MC9I60Kgh0EYSyUiP6qhzRDaQgwoCWDeX3GK1Z3m3xNXyfUQ7Q5n9i3Uk3W6UpMA6mwjrNbCDIQCaOHOaYZroQCawXILtxEKoIU7pxmuhQJoBsst3EZLCWBz3l6qiX2FRNcIzsQtowA93TvTm1m/fsV7Lcxj27rWMgIwC841YN5diUkhBAJ9bShcaPJcaC0hgJG8vdQl7JNEN2Ho0YjnDHS5wZYQQM6yH2DgallfGHq0JfyV+dlO5YETujlfuk4juk+FtFAAKizVhglUAGKHce/xJ+8j0HkqbocCUGGpNkygAjCt0jqAtim53AHXzopDNBq5V4FxGgi/ALRHDT3ytFL8PoECE8CW0V2nz7iamPh9XCU2Il7RzjmIFksOweD703rsehUO/MAEJoCcZe9klO8mlj4Mfjitx66QAlsUILsWnhlb0snoUBDuByYA07LfgWJ2MtflCzauiz0TBEGNtjlcLJ7YN7NE7Jaq+gSVVCMQAWTzpYuISHETCW039Mh6GYH1lG8bv+PUX//fdK+f6WxUYw3q1FRrC4DxyjTRBZv0yNv1dPBidXIF+yYwVjKwdA7zIjM/lE7GNnnZjrClKgAifDWViN7tdfsyey0tAD8mfqbl3A3w8orE+PCmMTw+fkLfZP//SDuCsCyViD4lw3ldHogAZn8Z9j1EuGmxgAh4KKVHF+xBbDT4udtL/qaaHWK60etEFwqJuR4x9OjljcZXT/3ABFBOmki0G8xnVXD8+WnQMs+Hfsv+DgNXVhUA8N2UHv1yPWQuVmeT5XykF/wkgM9/ABPwsbnABCCImMucmTw6TQ2Di/39vaPrV9/yppedIGyZli1m4ydK7B409Ohved22mHBOTk7HCSSu0RHPuwAe14CRIDfXBioAr0mW2TMtm2UYUd5NS86hACooIhSAys+kDTHhCPDBTuuyEUAlVy/vN/TYGW2o77pc7jIB2OKiC3HhRbWnq3YedZUAVFK1inSqQ4nB79X1c2rDSl0lANE/1VK1BrUeH6Ruuk4A5fWAhWlyxX8tSKcaZIc0u+3/B0Y1GSaZrFQgAAAAAElFTkSuQmCC"
						></image>
						<text class="load-text">{{ scroller.optUp.textLoading }}</text>
					</view>
					<!-- 无数据 -->
					<view v-if="!isDownLoading && isUpNoMore" class="upwarp-nodata">{{ scroller.optUp.textNoMore }}</view>
				</view>
			</view>
		</scroll-view>

		<!-- 回到顶部按钮 (fixed元素,需写在scroll-view外面,防止滚动的时候抖动)-->
		<image
			v-if="scroller.optUp.toTop.src"
			class="scroller-totop"
			:class="{ 'scroller-fade-in': isShowToTop }"
			:src="scroller.optUp.toTop.src"
			mode="widthFix"
			@click="toTopClick"
		/>
	</view>
</template>

<script>
// 引入scroller.js,处理核心逻辑
import Scroller from './scroller.js';
// 引入全局配置
import GlobalOption from './option.js';

export default {
	data() {
		return {
			scroller: null, // scroller实例
			viewId:
				'id_' +
				Math.random()
					.toString(36)
					.substr(2), // 随机生成scroller的id(不能数字开头,否则找不到元素)
			downHight: 0, //下拉刷新: 容器高度
			downRotate: 0, //下拉刷新: 圆形进度条旋转的角度
			downText: '', //下拉刷新: 提示的文本
			isDownReset: false, //下拉刷新: 是否显示重置的过渡动画
			isDownLoading: false, //下拉刷新: 是否显示加载中
			isUpLoading: false, // 上拉加载: 是否显示 "加载中..."
			isUpNoMore: false, // 上拉加载: 是否显示 "-- END --"
			isShowEmpty: false, // 是否显示空布局
			isShowToTop: false, // 是否显示回到顶部按钮
			scrollAble: true, // 是否禁止下滑 (下拉时禁止,避免抖动)
			scrollTop: 0, // 滚动条的位置
			scrollAnim: false, // 是否开启滚动动画
			windowTop: 0, // 可使用窗口的顶部位置
			windowBottom: 0 // 可使用窗口的底部位置
		};
	},
	props: {
		down: Object, // 下拉刷新的参数配置
		up: Object, // 上拉加载的参数配置
		top: [String, Number], // 下拉布局往下偏移的数值, 已默认单位为upx.
		bottom: [String, Number], // 上拉布局往上偏移的数值, 已默认单位为upx.
		fixed: {
			// 是否通过fixed固定scroller的高度, 默认true
			type: Boolean,
			default() {
				return true;
			}
		}
	},
	computed: {
		// top数值,单位upx,需转成px. 目的是使下拉布局往下偏移
		numTop() {
			return uni.upx2px(Number(this.top || 0));
		},
		fixedTop() {
			return this.fixed ? this.numTop + this.windowTop + 'px' : 0;
		},
		padTop() {
			return !this.fixed ? this.numTop + 'px' : 0;
		},
		// bottom数值,单位upx,需转成px 目的是使上拉布局往上偏移
		numBottom() {
			return uni.upx2px(Number(this.bottom || 0));
		},
		fixedBottom() {
			return this.fixed ? this.numBottom + this.windowBottom + 'px' : 0;
		},
		padBottom() {
			return !this.fixed ? this.numBottom + 'px' : 0;
		},
		// 空布局的配置
		optEmpty() {
			return this.scroller.optUp.empty;
		},
		// 过渡
		transition() {
			return this.isDownReset ? 'transform 300ms' : '';
		},
		translateY() {
			return this.downHight > 0 ? 'translateY(' + this.downHight + 'px)' : ''; // transform会使fixed失效,需注意把fixed元素写在scroller之外
		}
	},
	methods: {
		//注册列表滚动事件,用于下拉刷新
		scroll(e) {
			this.scroller.scroll(e.detail, () => {
				this.$emit('scroll', this.scroller); // 此时可直接通过 this.scroller.scrollTop获取滚动条位置; this.scroller.isScrollUp获取是否向上滑动
			});
		},
		//注册列表touchstart事件,用于下拉刷新
		touchstartEvent(e) {
			this.scroller.touchstartEvent(e);
		},
		//注册列表touchmove事件,用于下拉刷新
		touchmoveEvent(e) {
			this.scroller.touchmoveEvent(e);
		},
		//注册列表touchend事件,用于下拉刷新
		touchendEvent(e) {
			this.scroller.touchendEvent(e);
		},
		// 点击空布局的按钮回调
		emptyClick() {
			this.$emit('emptyclick', this.scroller);
		},
		// 点击回到顶部的按钮回调
		toTopClick() {
			this.isShowToTop = false; // 回到顶部按钮需要先隐藏,再执行回到顶部,避免闪动
			this.scroller.scrollTo(0, this.scroller.optUp.toTop.duration); // 执行回到顶部
			this.$emit('topclick', this.scroller); // 派发点击回到顶部按钮的回调
		},
		// 更新滚动区域的高度 (使内容不满屏和到底,都可继续翻页)
		setClientHeight() {
			if (this.scroller.getClientHeight(true) === 0 && !this.isExec) {
				this.isExec = true; // 避免多次获取
				this.$nextTick(() => {
					// 确保dom已渲染
					let view = uni
						.createSelectorQuery()
						.in(this)
						.select('#' + this.viewId);
					view.boundingClientRect(data => {
						this.isExec = false;
						if (data) {
							this.scroller.setClientHeight(data.height);
						} else if (this.clientNum != 3) {
							// 极少部分情况,可能dom还未渲染完毕,递归获取,最多重试3次
							this.clientNum = this.clientNum == null ? 1 : this.clientNum + 1;
							setTimeout(() => {
								this.setClientHeight();
							}, this.clientNum * 100);
						}
					}).exec();
				});
			}
		}
	},
	// 使用created初始化scroller对象; 如果用mounted部分css样式编译到H5会失效
	created() {
		let vm = this;

		let diyOption = {
			// 下拉刷新的配置
			down: {
				inOffset(scroller) {
					// 下拉的距离进入offset范围内那一刻的回调
					vm.scrollAble = false; // 禁止下拉,避免抖动 (自定义scroller组件时,此行不可删)
					vm.isDownReset = false; // 不重置高度 (自定义scroller组件时,此行不可删)
					vm.isDownLoading = false; // 不显示加载中
					vm.downText = scroller.optDown.textInOffset; // 设置文本
				},
				outOffset(scroller) {
					// 下拉的距离大于offset那一刻的回调
					vm.scrollAble = false; // 禁止下拉,避免抖动 (自定义scroller组件时,此行不可删)
					vm.isDownReset = false; // 不重置高度 (自定义scroller组件时,此行不可删)
					vm.isDownLoading = false; // 不显示加载中
					vm.downText = scroller.optDown.textOutOffset; // 设置文本
				},
				onMoving(scroller, rate, downHight) {
					// 下拉过程中的回调,滑动过程一直在执行; rate下拉区域当前高度与指定距离的比值(inOffset: rate<1; outOffset: rate>=1); downHight当前下拉区域的高度
					vm.downHight = downHight; // 设置下拉区域的高度 (自定义scroller组件时,此行不可删)
					vm.downRotate = 'rotate(' + 360 * rate + 'deg)'; // 设置旋转角度
				},
				showLoading(scroller, downHight) {
					// 显示下拉刷新进度的回调
					vm.scrollAble = true; // 开启下拉 (自定义scroller组件时,此行不可删)
					vm.isDownReset = true; // 重置高度 (自定义scroller组件时,此行不可删)
					vm.isDownLoading = true; // 显示加载中
					vm.downHight = downHight; // 设置下拉区域的高度 (自定义scroller组件时,此行不可删)
					vm.downText = scroller.optDown.textLoading; // 设置文本
				},
				endDownScroll(scroller) {
					vm.scrollAble = true; // 开启下拉 (自定义scroller组件时,此行不可删)
					vm.isDownReset = true; // 重置高度 (自定义scroller组件时,此行不可删)
					vm.isDownLoading = false; // 不显示加载中
					vm.downHight = 0; // 设置下拉区域的高度 (自定义scroller组件时,此行不可删)
				},
				// 派发下拉刷新的回调
				callback: function(scroller) {
					vm.$emit('down', scroller);
				}
			},
			// 上拉加载的配置
			up: {
				// 显示加载中的回调
				showLoading() {
					vm.isUpLoading = true;
					vm.isUpNoMore = false;
				},
				// 显示无更多数据的回调
				showNoMore() {
					vm.isUpLoading = false;
					vm.isUpNoMore = true;
				},
				// 隐藏上拉加载的回调
				hideUpScroll() {
					vm.isUpLoading = false;
					vm.isUpNoMore = false;
				},
				// 空布局
				empty: {
					onShow(isShow) {
						// 显示隐藏的回调
						vm.isShowEmpty = isShow;
					}
				},
				// 回到顶部
				toTop: {
					onShow(isShow) {
						// 显示隐藏的回调
						vm.isShowToTop = isShow;
					}
				},
				// 派发上拉加载的回调
				callback: function(scroller) {
					vm.$emit('up', scroller);
					// 更新容器的高度 (多scroller的情况)
					vm.setClientHeight();
				}
			}
		};

		Scroller.extend(diyOption, GlobalOption); // 混入全局的配置
		let myOption = JSON.parse(
			JSON.stringify({
				down: vm.down,
				up: vm.up
			})
		); // 深拷贝,避免对props的影响
		Scroller.extend(myOption, diyOption); // 混入具体界面的配置

		// 初始化Scroller对象
		vm.scroller = new Scroller(myOption);
		vm.scroller.viewId = vm.viewId; // 附带id
		// init回调scroller对象
		vm.$emit('init', vm.scroller);

		// 设置高度
		uni.getSystemInfo({
			success(res) {
				if (res.windowTop) vm.windowTop = res.windowTop; // 修正app和H5的top值
				if (res.windowBottom) vm.windowBottom = res.windowBottom; // 修正app和H5的bottom值
				vm.scroller.setBodyHeight(res.windowHeight); // 使down的bottomOffset生效
			}
		});

		// 因为使用的是scrollview,这里需自定义scrollTo
		vm.scroller.resetScrollTo((y, t) => {
			let curY = vm.scroller.getScrollTop();
			if (t === 0) {
				vm.scrollAnim = false;
				vm.scrollTop = curY;
				vm.$nextTick(function() {
					vm.scrollTop = y;
				});
			} else {
				vm.scrollAnim = true;
				vm.scroller.getStep(
					curY,
					y,
					step => {
						// 此写法可支持配置t
						vm.scrollTop = step;
					},
					t
				);
			}
		});
	},
	mounted() {
		// 设置容器的高度
		this.setClientHeight();
	}
};
</script>

<style>
@import './scroller.css';
</style>
