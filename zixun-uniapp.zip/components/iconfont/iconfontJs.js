export default {
  name: 'iconfontJs',
  render(createElement) {
  	return createElement('script', {
  		attrs: {
  			type: 'text/javascript',
  			src: '//at.alicdn.com/t/font_1235435_d4s38m5wnxf.js'
  		}
  	});
  }
}